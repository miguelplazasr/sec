<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

namespace SEC\SolicitudesBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SEC\SolicitudesBundle\Entity\Asignacion
 *
 * @ORM\Table(name="tb_asignacion")
 * @ORM\Entity(repositoryClass="SEC\SolicitudesBundle\Entity\AsignacionRepository")
 */

 class Asignacion {
     
     /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
     
    protected $id;


    /**
     * @ORM\Column(type="date")
     * @Assert\Date()
     */
    protected $fechaEnvio;
    
    /**
     * @ORM\Column(type="date")
     * @Assert\Date()
     */
    protected $fechaRecepcion;
    
    /**
     * @ORM\ManyToOne(targetEntity="Persona", inversedBy="asignaciones", cascade={"remove"})
     * @ORM\JoinColumn(name="Person_id", referencedColumnName="id")
     */
    
    protected $persona;
    
    /**
     * @ORM\ManyToOne(targetEntity="Proceso", inversedBy="asignaciones", cascade={"remove"})
     * @ORM\JoinColumn(name="Proceso_id", referencedColumnName="id")
     */
    
    protected $proceso;


    


    
    
    /**
     * @var datetime $created
     * 
     * @ORM\Column( type="datetime")
     * @Gedmo\Timestampable(on="create")
     * 
     */
    
    private $created_at;


    
    /**
     * @var datetime $updated
     * 
     * @ORM\Column(type="datetime")
     * @Gedmo\Timestampable(on="update")
     */
    
    private $update_at;


    


    


    
            

}


?>
