<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

namespace SEC\SolicitudesBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SEC\SolicitudesBundle\Entity\Proceso
 *
 * @ORM\Table(name="tb_preceso")
 * @ORM\Entity(repositoryClass="SEC\SolicitudesBundle\Entity\ProcesoRepository")
 */

 class Proceso {
     
     /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
     
    protected $id;


    /**
     * @ORM\Column(type="date")
     * @Assert\Date()
     */
    protected $fechaRecSDA;
    
    /**
     * @ORM\Column(type="date")
     * @Assert\Date()
     */
    protected $fechaRecSER;
    
    /**
     * @ORM\Column(type="string")
     * @Assert\NotBlank()
     * @Assert\MaxLength(255)
     */
    
    protected $titulo;
    
    /**
     * @ORM\Column(type="string", length=100)
     * @Assert\NotBlank()
     * @Assert\MaxLength(255)
     */
    
    protected $resumen;
    
    
    /**
     * @ORM\OneToMany(targetEntity="Asignacion", mappedBy="proceso")
     */
    Private $asignaciones;

    /**
     * @ORM\ManyToOne(targetEntity="EnteControl", inversedBy="procesos", cascade={"remove"})
     * @ORM\JoinColumn(name="EnteControl_id", referencedColumnName="id")
     */
    
    protected $entecontrol;


    
        
    /**
     * @var datetime $created
     * 
     * @ORM\Column( type="datetime")
     * @Gedmo\Timestampable(on="create")
     * 
     */
    
    private $created_at;


    
    /**
     * @var datetime $updated
     * 
     * @ORM\Column(type="datetime")
     * @Gedmo\Timestampable(on="update")
     */
    
    private $update_at;


    


    


    


    


    
            

}


?>
